<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "kuisweb_022";
$connect = new mysqli($hostname, $username, $password, $database);
