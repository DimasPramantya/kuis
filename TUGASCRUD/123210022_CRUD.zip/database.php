<?php
$database = "toko_dvd";
$hostname = "localhost";
$username = "root";
$password = "";

$connection = new mysqli($hostname,$username,$password, $database);